package srg.ports;

import org.junit.Test;
import static org.junit.Assert.*;


public class PositionTest {
    @Test
    public void testdistanceTo() {
        Position p1 = new Position(0, 0, 0);
        Position p2 = new Position(1, 2, 3);
        assertEquals(3, p1.distanceTo(p2));
    }
    @Test
    public void testtoString() {
        Position p1 = new Position(867, 439, 300);
        assertEquals("(867, 439, 300)", p1.toString());
    }
}
