package srg.resources;

import org.junit.Test;
import static org.junit.Assert.*;

public class ResourceContainerTest {
    @Test
    public void testConstructor() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 10);
        assertEquals(ResourceType.REPAIR_KIT, container.getType());
        assertEquals("REPAIR_KIT", container.getShortName());
        assertEquals(10, container.getAmount());
    }
    @Test(expected = IllegalArgumentException.class)
    public void testThorwExpection() {
        new ResourceContainer(null, 10);
        new ResourceContainer(ResourceType.FUEL, 100);
        //expected = IllegalArgumentException.class;
    }
    @Test
    public void testCanStore() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 100);
        assertFalse(container.canStore(ResourceType.FUEL));
        assertTrue(container.canStore(ResourceType.REPAIR_KIT));
    }
    @Test
    public void testGetAmount() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 5);
        assertEquals(5, container.getAmount());
    }
    @Test
    public void testSetAmount() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 5);
        container.setAmount(7);
        assertEquals(7, container.getAmount());
    }
    @Test
    public void testToString() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 5);
        assertEquals("REPAIR_KIT: 5", container.toString());
    }
    @Test
    public void testGetType() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 5);
        assertEquals(ResourceType.REPAIR_KIT, container.getType());
    }
    @Test
    public void testGetShortName() {
        ResourceContainer container = new ResourceContainer(ResourceType.REPAIR_KIT, 5);
        assertEquals("REPAIR_KIT", container.getShortName());
    }
}
