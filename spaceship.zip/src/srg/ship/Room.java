package srg.ship;

import java.util.List;
import java.util.ArrayList;

/**
 * Represents a Room in a Ship. Rooms are Damageable objects.
 * Rooms also have a tier which contributes to determining starting health and damage rate.
 */
public class Room implements Damageable {

    /**
     * The tier of this Room.
     */
    private RoomTier tier;

    /**
     * The damage rate of this Room.
     */
    private int damageRate;

    /**
     * The maximum health of this Room.
     */
    private int maxHealth;

    /**
     * The current health of this Room.
     */
    private int health;

    /**
     * Constructs a Room and assigns it a tier. The following class variables have default values:
     * damageRate is determined by the Room's tier and Damageable's DAMAGE_RATE.
     * health is initially determined by the Room's tier and Damageable's HEALTH_MULTIPLIER.
     * maxHealth is determined by the Room's tier and Damageable's HEALTH_MULTIPLIER.
     * @param tier The RoomTier of this Room.
     */
    public Room(RoomTier tier) {
        this.tier = tier;
        this.damageRate = tier.damageMultiplier * Damageable.DAMAGE_RATE;
        this.maxHealth = tier.healthMultiplier * Damageable.HEALTH_MULTIPLIER;
        this.health = this.maxHealth;
    }

    /**
     * Constructs a Room with a default tier of BASIC.
     */
    public Room() {
        this(RoomTier.BASIC);
    }

    /**
     * Upgrades a Room based on its current tier.
     */
    public void upgrade() {
        if (this.tier == RoomTier.BASIC) {
            this.tier = RoomTier.AVERAGE;
            this.damageRate = tier.damageMultiplier * Damageable.DAMAGE_RATE;
            this.maxHealth = tier.healthMultiplier * Damageable.HEALTH_MULTIPLIER;
            this.health = maxHealth;
        } else if (this.tier == RoomTier.AVERAGE) {
            this.tier = RoomTier.PRIME;
            this.damageRate = tier.damageMultiplier * Damageable.DAMAGE_RATE;
            this.maxHealth = tier.healthMultiplier * Damageable.HEALTH_MULTIPLIER;
            this.health = maxHealth;
        } else {
            this.tier = RoomTier.PRIME;
            this.health = this.maxHealth;
            System.out.println("This room can't be upgraded.");
        }
    }

    /**
     * Sets the damage rate of a Damageable object to newDamageRate
     * @param newDamageRate The new damage rate of the Damageable object
     */
    public void setDamageRate(int newDamageRate) {
        this.damageRate = newDamageRate;
    }

    /**
     * Gets the damage rate of a Damageable object
     * @return The damage rate of the Damageable object
     */
    public int getHealth() {
        double result = (double) this.health / (double) this.maxHealth * 100;
        return (int) result;
    }

    /**
     * Applies damage to the Damageable object at the appropriate rate.
     */
    public void damage() {
        this.health -= this.damageRate;
    }

    /**
     * Recalculates maximum health and resets health to maximum.
     */
    public void resetHealth() {
        this.health = this.maxHealth;
    }

    /**
     * Gets the status of Room's tier
     * @return whether the Room needs repair
     */
    public RoomTier getTier() {
        return this.tier;
    }

    /**
     * Gets the status of Room's health
     * @return A String of the format "ROOM: room name(room tier) health: health%, needs repair: boolean"
     */
    public String toString() {
        return "ROOM: " + this.getClass().getSimpleName() + "(" + this.getTier() + ") health: "
                + this.getHealth() + "%, needs repair: " + this.needsRepair();
    }

    /**
     * Get the list of actions that it is possible to perform from this Room. Generic Rooms have no actions.
     * @return A list of the names of the actions that it is possible to perform from this Room.
     */
    public List<String> getActions() {
        return new ArrayList<String>();
    }
}
