package srg.ship;

/**
 * Damageable is an interface that defines the behavior of objects that can be damaged.
 */
public interface Damageable {

    /**
     * The rate at which damage occurs to a Damageable object is determined by the DAMAGE_RATE and some feature of
     * the object's class.
     */
    static final int DAMAGE_RATE = 5;

    /**
     * The maximum health of a Damageable object is determined by the MAX_HEALTH_MULTIPLIER and some feature of the
     * object's class.
     */
    static final int HEALTH_MULTIPLIER = 5;

    /**
     * The threshold at which a Damageable object must be repaired. Required value: 30
     */
    static final int REPAIR_THRESHOLD = 30;

    /**
     * Get the health as an integer percentage of the maximum.
     * @return the health as an integer percentage of the maximum.
     */
    int getHealth();

    /**
     * Returns whether the current object needs repair. If the percentage health (rounded-down) is less than or
     * equal to 30% then repair is needed, or further use of the item will lead to damage.
     * @return true if the object needs repair, false otherwise.
     */
    default boolean needsRepair() {
        if (getHealth() <= REPAIR_THRESHOLD) {
            return true;
        }
        return false;
    }

    /**
     * Applies damage to the Damageable object at the appropriate rate.
     */
    void damage();

    /**
     * Returns whether the current object is non-functional. If the percentage health (rounded-down) is less than or
     * equal to 0% then the object is broken.
     * @return true if the object is broken, false otherwise.
     */
    default boolean isBroken() {
        if (getHealth() <= 0) {
            return true;
        }
        return false;
    }

    /**
     * Recalculates maximum health and resets health to maximum.
     */
    void resetHealth();

    /**
     * Sets the damage rate of a Damageable object to newDamageRate
     * @param newDamageRate the new damage rate of the object.
     */
    void setDamageRate(int newDamageRate);
}
