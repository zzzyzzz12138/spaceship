package srg.ship;

import srg.ports.*;
import srg.exceptions.InsufficientResourcesException;
import srg.exceptions.NoPathException;
import srg.ports.SpacePort;
import srg.resources.FuelGrade;

import java.util.ArrayList;
import java.util.List;

/**
  * Child class of Room which represents a NavigationRoom in a Ship.
  * NavigationRooms track the Ship's current Port and the galaxy map which lists all SpacePorts in the galaxy.
  * NavigationRooms also track which SpacePorts the Ship could fly to (shorter distance) or jump to (longer distance).
 */
public class NavigationRoom extends Room implements Damageable {

    /**
     * The galaxy map which lists all SpacePorts in the galaxy.
     */
    public List<SpacePort> galaxyMap;

    /**
     * The current SpacePort the Ship is at.
     */
    private SpacePort currentPort;

    /**
     * The maximum distance the Ship can fly to.
     */
    private int maxFlyDistance;

    /**
     * The maximum distance the Ship can jump to.
     */
    private int maxJumpDistance;

    /**
     * Constructs a NavigationRoom with the specified RoomTier and galaxy map.
     * @param roomTier The RoomTier of this NavigationRoom.
     * @param galaxyMap The galaxy map which lists all SpacePorts in the galaxy.
     */
    public NavigationRoom(RoomTier roomTier, List<SpacePort> galaxyMap) {
        super(roomTier);
        this.galaxyMap = galaxyMap;
        this.currentPort = galaxyMap.get(0);
    }

    /**
     * Returns the current SpacePort.
     * @return The current SpacePort the Ship is at.
     */
    public SpacePort getCurrentPort() {
        return this.currentPort;
    }

    /**
     * Returns a List of SpacePorts the Ship could fly to. This List should not include the current SpacePort
     * @return A List of SpacePorts the Ship could fly to.
     */
    public List<SpacePort> getPortsInFlyRange() {
        ArrayList<SpacePort> portsInFlyRange = new ArrayList<>();
        for (SpacePort port : galaxyMap) {
            if (port.getPosition().distanceTo(this.currentPort.getPosition())
                    <= this.getMaximumFlyDistance() && port != this.currentPort) {
                portsInFlyRange.add(port);
            }
        }
        return portsInFlyRange;
    }

    /**
     * Returns the maximum distance the Ship can fly to.
     * @return The maximum distance the Ship can fly to.
     */
    public int getMaximumFlyDistance() {
        if (this.getTier() == RoomTier.BASIC) {
            maxFlyDistance = 200;
        } else if (this.getTier() == RoomTier.AVERAGE) {
            maxFlyDistance = 400;
        } else if (this.getTier() == RoomTier.PRIME) {
            maxFlyDistance = 600;
        }
        return maxFlyDistance;
    }

    /**
     *This is determined by the quality of the NavigationRoom, as defined by the RoomTier enum.
     * @return The maximum distance the Ship can jump to.
     */
    public int getMaximumJumpDistance() {
        //Maximum jump distance as an int.
        // This is determined by the quality of the NavigationRoom, as defined by the RoomTier enum.
        // BASIC NavigationRooms can jump 500 units. AVERAGE NavigationRooms can jump 750 units.
        // PRIME NavigationRooms can jump 1000 units.
        if (this.getTier() == RoomTier.BASIC) {
            maxJumpDistance = 500;
        } else if (this.getTier() == RoomTier.AVERAGE) {
            maxJumpDistance = 750;
        } else if (this.getTier() == RoomTier.PRIME) {
            maxJumpDistance = 1000;
        }
        return maxJumpDistance;
    }

    /**
     * Returns a List of SpacePorts the Ship could jump to.
     * @return A List of SpacePorts the Ship could jump to.
     */
    public List<SpacePort> getPortsInJumpRange() {
        ArrayList<SpacePort> portsInJumpRange = new ArrayList<SpacePort>();
        for (SpacePort port : galaxyMap) {
            if (port.getPosition().distanceTo(this.currentPort.getPosition())
                    <= this.getMaximumJumpDistance() && port != this.currentPort
                    && !this.getPortsInFlyRange().contains(port)) {
                portsInJumpRange.add(port);
            }
        }
        return portsInJumpRange;
    }

    /**
     * Returns a List of Strings representing the actions that can be performed in this NavigationRoom.
     * @return A List of actions that this NavigationRoom can perform as Strings.
     * Format must be: fly to "port1": PORT: "port1" SpacePort at (0, 0, 110) [COST: 110 TRITIUM FUEL]
     * jump to "port1" [COST: 1 HYPERDRIVE CORE]
     */
    public List<String> getActions() {
        List<String> actions = new ArrayList<String>();
        for (SpacePort port : this.getPortsInFlyRange()) {
            if (this.getPortsInFlyRange().contains(port)) {
                actions.add(String.format("fly to \"%s\": PORT: \"%s\" %s at %s "
                                + "[COST: %d TRITIUM FUEL]",
                        port.getName(), port.getName(), port.getClass().getSimpleName(),
                        port.getPosition(),
                        this.currentPort.getPosition().distanceTo(port.getPosition())));
            }
        }
        for (SpacePort port : this.getPortsInJumpRange()) {
            if (this.getPortsInJumpRange().contains(port)) {
                actions.add(String.format("jump to \"%s\" [COST: 1 HYPERDRIVE CORE]",
                        port.getName()));
            }
        }
        return actions;
    }

    /**
     * Returns the amount of fuel required to travel to another SpacePort.
     * @param port The SpacePort to travel to.
     * @return The amount of fuel required to travel to another SpacePort.
     */
    public int getFuelNeeded(SpacePort port) {
        return port.getPosition().distanceTo(this.currentPort.getPosition());
    }

    /**
     * Checks if the current port is a ShipYard
     * @return The current port if it is a ShipYard, null otherwise.
     */
    public ShipYard getShipYard() {
        //Checks if the current port is a ShipYard
        if (this.currentPort instanceof ShipYard) {
            return (ShipYard) this.currentPort;
        }
        return null;
    }

    /**
     * Checks if the current port is a Store
     * @return The current port if it is a Store, null otherwise.
     */
    public Store getStore() {
        //Checks if the current port is a Store
        if (this.currentPort instanceof Store) {
            return (Store) this.currentPort;
        }
        return null;
    }

    /**
     * Flies the Ship to the specified SpacePort if it is in range, and the ship is able to support the journey.
     * Ship's Rooms take damage at their damage rate when flying.
     * Flying requires TRITIUM fuel. TRITIUM is used up at a rate of one unit per unit of distance travelled.
     * NoPathException - If the named SpacePort cannot be found or is out of range.
     * @param portName The name of the SpacePort to fly to.
     * @param cargoHold The Ship's CargoHold.
     */
    public void flyTo(String portName, CargoHold cargoHold)
            throws InsufficientResourcesException, NoPathException {
        List<String> canFlyTo = new ArrayList<>();
        if (cargoHold.isBroken() || this.isBroken()
                || this.getFuelNeeded(this.getSpacePortFromName(portName))
                > cargoHold.getTotalAmountByType(FuelGrade.TRITIUM)) {
            throw new InsufficientResourcesException("InsufficientResourcesException");
        } else {
            for (SpacePort port : this.getPortsInFlyRange()) {
                canFlyTo.add(port.getName());
            }
            if (!canFlyTo.contains(portName)) {
                throw new NoPathException("NoPathException");
            }
            //the named SpacePort cannot be found
            if (!galaxyMap.contains(this.getSpacePortFromName(portName))) {
                throw new NoPathException("NoPathException");
            } else {
                cargoHold.consumeResource(FuelGrade.TRITIUM,
                        this.getFuelNeeded(this.getSpacePortFromName(portName)));
                cargoHold.damage();
                this.damage();
                this.currentPort = this.getSpacePortFromName(portName);
            }
        }
    }

    /**
     * Jumps the Ship to the specified SpacePort if it is in range, and the ship is able to support the journey.
     * Ship's Rooms take damage at their damage rate when jumping.
     * Jumping requires HYPERDRIVE CORES. One HYPERDRIVE CORE is used up per jump.
     * NoPathException - If the named SpacePort cannot be found or is out of range.
     * @param portName The name of the SpacePort to jump to.
     * @param cargoHold The Ship's CargoHold.
     */
    public void jumpTo(String portName, CargoHold cargoHold)
            throws InsufficientResourcesException, NoPathException {
        List<String> canJumpTo = new ArrayList<>();
        if (cargoHold.isBroken() || this.isBroken()
                || cargoHold.getTotalAmountByType(FuelGrade.HYPERDRIVE_CORE) < 0) {
            throw new InsufficientResourcesException("InsufficientResourcesException");
        } else {
            for (SpacePort port : this.getPortsInJumpRange()) {
                canJumpTo.add(port.getName());
            }
            if (!canJumpTo.contains(portName)) {
                throw new NoPathException("NoPathException");
            }
            if (!galaxyMap.contains(this.getSpacePortFromName(portName))) {
                throw new NoPathException("NoPathException");
            } else {
                this.currentPort = this.getSpacePortFromName(portName);
                cargoHold.consumeResource(FuelGrade.HYPERDRIVE_CORE, 1);
                cargoHold.damage();
                this.damage();
            }
        }
    }

    /**
     * Returns the SpacePort with the specified name.
     * @param name The name of the SpacePort to return.
     * @return The specified SpacePort if it can be found.
     * @throws NoPathException If the named SpacePort cannot be found.
     */
    public SpacePort getSpacePortFromName(String name) throws NoPathException {
        for (SpacePort port : galaxyMap) {
            if (port.getName().equals(name)) {
                return port;
            }
        }
        throw new NoPathException("NoPathException");
    }
}
