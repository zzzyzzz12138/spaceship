package srg.ship;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Iterator;

import srg.resources.FuelGrade;
import srg.resources.FuelContainer;
import srg.resources.ResourceContainer;
import srg.resources.ResourceType;
import srg.exceptions.*;

/**
 * A child class of Room which is able to store ResourceContainers
 */
public class CargoHold extends Room implements Damageable {

    /**
     * The tier of this CargoHold
     */
    private RoomTier tier;

    /**
     * The list of ResourceContainers stored by this CargoHold
     */
    private List<ResourceContainer> resources;

    /**
     * Constructor which creates a CargoHold at a specific RoomTier
     * @param roomTier The RoomTier of this CargoHold
     */
    public CargoHold(RoomTier roomTier) {
        //Constructor which creates a CargoHold at a specific RoomTier
        super(roomTier);
        this.tier = roomTier;
        this.resources = new ArrayList<>();
    }

    /**
     * Returns the remaining capacity of the CargoHold for new ResourceContainers
     * @return The remaining capacity of the CargoHold for new ResourceContainers
     */
    public int getRemainingCapacity() {
        int remainingCapacity = this.getMaximumCapacity();
        return remainingCapacity - resources.size();
    }

    /**
     * Returns the maximum capacity of the CargoHold based on its tier
     * @return The maximum capacity of the CargoHold based on its tier
     */
    public int getMaximumCapacity() {
        if (this.tier == RoomTier.BASIC) {
            return 5;
        } else if (this.tier == RoomTier.AVERAGE) {
            return 10;
        } else {
            return 15;
        }
    }

    /**
     * Gets the List of ResourceContainers stored by this CargoHold.
     * @return The total amount of a given ResourceType stored in the CargoHold
     */
    public List<ResourceContainer> getResources() {
        return this.resources;
    }

    /**
     * Attempts to add a new ResourceContainer to this CargoHold.
     * @param resource The ResourceContainer to add to this CargoHold
     */
    public void storeResource(ResourceContainer resource) throws InsufficientCapcaityException {
        if (this.getRemainingCapacity() <= 0) {
            throw new InsufficientCapcaityException("InsufficientCapcaityException ");
        } else {
            this.resources.add(resource);
        }
    }

    /**
     * Get a List of ResourceContainers holding a given ResourceType
     * @param type The ResourceType of the ResourceContainer to remove from this CargoHold
     * @return The ResourceContainer removed from this CargoHold
     */
    public List<ResourceContainer> getResourceByType(ResourceType type) {
        List<ResourceContainer> resourceByType = new ArrayList<>();
        for (ResourceContainer resource : resources) {
            if (resource.getType() == type) {
                resourceByType.add(resource);
            }
        }
        return resourceByType;
    }

    /**
     * Get a list of ResourceContainers holding Fuel of a particular grade.
     * @param grade The FuelGrade of the ResourceContainer to remove from this CargoHold
     * @return The ResourceContainer removed from this CargoHold
     */
    public List<ResourceContainer> getResourceByType(FuelGrade grade) {
        List<ResourceContainer> resourceByTypeFuel = new ArrayList<>();
        for (ResourceContainer resource : resources) {
            if (resource.getClass() == FuelContainer.class) {
                FuelContainer fuel = (FuelContainer) resource;
                if (fuel.getFuelGrade() == grade) {
                    resourceByTypeFuel.add(resource);
                }
            }
        }
        return resourceByTypeFuel;
    }

    /**
     * Sums the quantity of a given resource in the ResourceContainers.
     * @param type The ResourceType of the ResourceContainer to remove from this CargoHold
     * @return The total amount of a given ResourceType stored in the CargoHold
     */
    public int getTotalAmountByType(ResourceType type) {
        int totalAmount = 0;
        for (ResourceContainer resource : resources) {
            if (resource.getClass() != FuelContainer.class) {
                if (resource.getType() == type) {
                    totalAmount += resource.getAmount();
                }
            }
        }
        return totalAmount;
    }

    /**
     * Sums the quantity of a given fuel in the ResourceContainers
     * @param grade The FuelGrade of the ResourceContainer to remove from this CargoHold
     * @return The total amount of a given FuelGrade stored in the CargoHold
     */
    public int getTotalAmountByType(FuelGrade grade) {
        int totalAmountFuel = 0;
        for (ResourceContainer resource : resources) {
            if (resource.getClass() == FuelContainer.class) {
                FuelContainer fuel = (FuelContainer) resource;
                if (fuel.getFuelGrade() == grade) {
                    totalAmountFuel += resource.getAmount();
                }
            }
        }
        return totalAmountFuel;
    }

    /**
     * Consumes the specified amount of resources. Empty ResourceContainers may be removed.
     * @param type The ResourceType of the ResourceContainer to remove from this CargoHold
     * @param amount The amount of the ResourceType to consume
     * @throws InsufficientResourcesException
     * If the amount of the specified ResourceType is less than the amount to consume
     */
    public void consumeResource(ResourceType type, int amount)
            throws InsufficientResourcesException {
        if (type == ResourceType.FUEL) {
            throw new IllegalArgumentException("IllegalArgumentException");
        }
        if (this.getTotalAmountByType(type) < amount) {
            throw new InsufficientResourcesException("InsufficientResourcesException");
        } else {
            Iterator<ResourceContainer> resourcesIterator = resources.iterator();
            while (resourcesIterator.hasNext()) {
                ResourceContainer resource = resourcesIterator.next();
                if (resource.getType() == type) {
                    resource.setAmount(resource.getAmount() - amount);
                    if (resource.getAmount() == 0) {
                        resourcesIterator.remove();
                    }
                }
            }
        }
    }

    /**
     * Consumes the specified amount of fuel resources. Empty FuelContainers may be removed.
     * @param grade The FuelGrade of the ResourceContainer to remove from this CargoHold
     * @param amount The amount of the FuelGrade to consume
     * @throws InsufficientResourcesException
     * If the amount of the specified FuelGrade is less than the amount to consume
     */
    public void consumeResource(FuelGrade grade, int amount) throws InsufficientResourcesException {
        if (this.getTotalAmountByType(grade) < amount) {
            throw new InsufficientResourcesException("InsufficientResourcesException");
        } else {
            Iterator<ResourceContainer> resourcesIterator = resources.iterator();
            while (resourcesIterator.hasNext()) {
                ResourceContainer resource = resourcesIterator.next();
                if (resource.getClass() == FuelContainer.class) {
                    FuelContainer fuel = (FuelContainer) resource;
                    if (fuel.getFuelGrade() == grade) {
                        fuel.setAmount(fuel.getAmount() - amount);
                        if (fuel.getAmount() == 0) {
                            resourcesIterator.remove();
                        }
                    }
                }
            }
        }
    }

    /**
     * A String of the format "ROOM: room name (room tier) health: health%, needs repair: boolean,
     * @return The total amount of resources stored in this CargoHold
     */
    public String toString() {
        List<String> items = new ArrayList<>();
        for (ResourceContainer item : this.getResources()) {
            items.add("    " + item.toString());
        }
        String itemsString = items.stream().collect(Collectors.joining("\n"));
        return "ROOM: " + this.getClass().getSimpleName() + "(" + this.getTier() + ") health: "
                + this.getHealth() + "%, needs repair: " + this.needsRepair() + ", capacity: "
                + this.getMaximumCapacity() + ", items: " + this.getResources().size() + "\n"
                + itemsString;
    }

    /**
     *Get the list of actions that it is possible to perform from this CargoHold.
     *A CargoHold is able to repair Rooms in the Ship if it has any REPAIR_KITs available.
     * @return A list of actions that can be performed on this CargoHold.
     */
    public List<String> getActions() {
        List<String> actions = new ArrayList<>();
        if (this.getTotalAmountByType(ResourceType.REPAIR_KIT) > 0) {
            actions.add("repair NavigationRoom [COST: 1 REPAIR_KIT]");
            actions.add("repair CargoHold [COST: 1 REPAIR_KIT]");
        }
        return actions;
    }
}
