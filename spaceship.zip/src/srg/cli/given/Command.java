package srg.cli.given;

public class Command {
    public final CommandType type;

    public Command(CommandType type) {
        this.type = type;
    }

}
