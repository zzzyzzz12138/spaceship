package srg.ports;

/**
 * Position is in 3 dimensions.
 * It is defined by its x, y, and z coordinates.
 */
public class Position {

    /**
     * The x-coordinate
     */
    public final int x;

    /**
     * The y-coordinate
     */
    public final int y;

    /**
     * The z-coordinate
     */
    public final int z;

    /**
     * Constructs a Position object with the specified x, y, and z coordinates.
     * @param x The x-coordinate
     * @param y The y-coordinate
     * @param z The z-coordinate
     */
    public Position(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    /**
     * calculates the distance between this point and another point
     * @param other the other point
     * @return the distance between this point and the other point
     */
    public int distanceTo(Position other) {
        return (int) Math.floor(Math.sqrt(Math.pow((this.x - other.x), 2)
                + Math.pow((this.y - other.y), 2) + Math.pow((this.z - other.z), 2)));
    }

    /**
     * Returns a formatted string representation of the Position.
     * @return a formatted string representation of the Position.
     */
    public String toString() {
        return String.format("(%d, %d, %d)", this.x, this.y, this.z);
    }
}
