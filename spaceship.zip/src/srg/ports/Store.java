package srg.ports;

import srg.exceptions.InsufficientCapcaityException;
import srg.exceptions.InsufficientResourcesException;
import srg.resources.*;
import srg.ship.CargoHold;
import srg.ship.RoomTier;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a SpacePort, which has a unique name, a unique ID, a position, and a CargoHold.
 */
public class Store extends SpacePort {

    /**
     * The cargo hold of the SpacePort.
     */
    private CargoHold cargoHold;

    /**
     * Creates a new SpacePort with the given name, position, and cargo hold tier.
     * @param name The name of the SpacePort.
     * @param position The position of the SpacePort.
     */
    public Store(String name, Position position) {
        super(name, position);
        this.cargoHold = new CargoHold(RoomTier.AVERAGE);
        try {
            this.cargoHold.storeResource(new ResourceContainer(ResourceType.REPAIR_KIT, 10));
        } catch (InsufficientCapcaityException ignored) {
            System.out.println("InsufficientCapcaityException");
        }
        try {
            this.cargoHold.storeResource(new FuelContainer(FuelGrade.TRITIUM, 1000));
        } catch (InsufficientCapcaityException ignored) {
            System.out.println("InsufficientCapcaityException");
        }
        try {
            this.cargoHold.storeResource(new FuelContainer(FuelGrade.HYPERDRIVE_CORE, 1000));
        } catch (InsufficientCapcaityException ignored) {
            System.out.println("InsufficientCapcaityException");
        }
    }

    /**
     * Remove an item from the store, and return a resource container containing the appropriate amount of the
     * same item.
     * If there is not enough resource available, InsufficientResourceException is propagated up.
     * @param item the item to be purchased.
     * @param amount the amount of the item to be purchased.
     * @return a resource container containing the appropriate amount of the same item.
     */
    public ResourceContainer purchase(String item, int amount)
            throws InsufficientResourcesException {
        if (item.equals("REPAIR_KIT")) {
            if (amount > this.cargoHold.getTotalAmountByType(ResourceType.REPAIR_KIT)) {
                throw new InsufficientResourcesException("InsufficientResourcesException");
            } else {
                this.cargoHold.consumeResource(ResourceType.REPAIR_KIT, amount);
                return new ResourceContainer(ResourceType.REPAIR_KIT, amount);
            }
        } else if (item.equals("TRITIUM")) {
            if (amount > this.cargoHold.getTotalAmountByType(FuelGrade.TRITIUM)) {
                throw new InsufficientResourcesException("InsufficientResourcesException");
            } else {
                this.cargoHold.consumeResource(FuelGrade.TRITIUM, amount);
                return new FuelContainer(FuelGrade.TRITIUM, amount);
            }
        } else if (item.equals("HYPERDRIVE_CORE")) {
            if (amount > this.cargoHold.getTotalAmountByType(FuelGrade.HYPERDRIVE_CORE)) {
                throw new InsufficientResourcesException("InsufficientResourcesException");
            } else {
                this.cargoHold.consumeResource(FuelGrade.HYPERDRIVE_CORE, amount);
                return new FuelContainer(FuelGrade.HYPERDRIVE_CORE, amount);
            }
        } else {
            throw new InsufficientResourcesException("The specified resource does not exist.");
        }
    }

    /**
     * Get the list of actions that it is possible to perform at this SpacePort.
     * Stores sell items that appear in their inventory.
     * @return Action Strings must be formatted as "buy item name 1..maximum number available"
     */
    public List<String> getActions() {
        List<String> actions = new ArrayList<String>();
        if (this.cargoHold.getTotalAmountByType(ResourceType.REPAIR_KIT) > 0) {
            actions.add("buy REPAIR_KIT 1.."
                    + this.cargoHold.getTotalAmountByType(ResourceType.REPAIR_KIT));
        }
        if (this.cargoHold.getTotalAmountByType(FuelGrade.TRITIUM) > 0) {
            actions.add("buy TRITIUM 1.." + this.cargoHold.getTotalAmountByType(FuelGrade.TRITIUM));
        }
        if (this.cargoHold.getTotalAmountByType(FuelGrade.HYPERDRIVE_CORE) > 0) {
            actions.add("buy HYPERDRIVE_CORE 1.."
                    + this.cargoHold.getTotalAmountByType(FuelGrade.HYPERDRIVE_CORE));
        }
        return actions;
    }
}
