package srg.ports;

import java.util.ArrayList;
import java.util.List;
import srg.ship.Room;

/**
 * A ShipYard is a SpacePort that can upgrade Rooms.
 */
public class ShipYard extends SpacePort {

    /**
     * A list of the names of the Rooms that this ShipYard can upgrade.
     */
    private List<String> canUpgrade;

    /**
     * Constructs a ShipYard.
     * @param name The name of the ShipYard.
     * @param position The position of the ShipYard.
     * @param canUpgrade A list of the names of the Rooms that this ShipYard can upgrade.
     */
    public ShipYard(String name, Position position, List<String> canUpgrade) {
        //Constructs a ShipYard
        super(name, position);
        this.canUpgrade = canUpgrade;
    }

    /**
     * Upgrades a Room.
     * @param room The Room to upgrade.
     */
    public void upgrade(Room room) {
        //Upgrades a Room
        if (canUpgrade.contains(room.getClass().getSimpleName())) {
            room.upgrade();
        } else {
            throw new IllegalArgumentException("This ShipYard cannot upgrade this Room.");
        }
    }

    /**
     * Returns a list of the names of the Rooms that this ShipYard can upgrade.
     * @return A list of the names of the Rooms that this ShipYard can upgrade.
     */
    public List<String> getActions() {
        ArrayList<String> actions = new ArrayList<String>();
        for (String room : canUpgrade) {
            actions.add("upgrade " + room);
        }
        return actions;
    }
}
