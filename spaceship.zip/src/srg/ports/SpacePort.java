package srg.ports;

import java.util.List;
import java.util.ArrayList;

/**
 * This class represents a generic SpacePort.
 */
public class SpacePort {

    /**
     * The name of the SpacePort.
     */
    private final String name;

    /**
     * The position of the SpacePort.
     */
    private final Position position;

    /**
     * Constructs a SpacePort.
     * @param name The name of the SpacePort.
     * @param position The position of the SpacePort.
     */
    public SpacePort(String name, Position position) {
        this.name = name;
        this.position = position;
    }

    /**
     * Returns the name of the SpacePort.
     * @return The name of the SpacePort.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Returns the position of the SpacePort.
     * @return The position of the SpacePort.
     */
    public Position getPosition() {
        return this.position;
    }

    /**
     * Returns a String representation of a SpacePort. Identifies the name, type of SpacePort and position.
     * @return a String representation of a SpacePort. Identifies the name, type of SpacePort and position.
     */
    public String toString() {
        return String.format("PORT: \"%s\" %s at %s", this.name,
                this.getClass().getSimpleName(), this.position);
    }

    /**
     * Get the list of actions that it is possible to perform at this SpacePort. Generic SpacePorts have no actions.
     * @return A list of the actions that it is possible to perform at this SpacePort.
     */
    public List<String> getActions() {
        return new ArrayList<String>();
    }
}
