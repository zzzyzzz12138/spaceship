package srg.resources;

/**
 * Enumerates the valid types of resources
 * @version 1.0
 * @ass1
 */
public enum ResourceType {
    /**
     * Consumable resource used for flying or jumping.
     */
    FUEL,
    /**
     * Consumable resource used for repairing Rooms in a Ship.
     */
    REPAIR_KIT
}
