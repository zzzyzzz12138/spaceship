package srg.resources;

/**
 * A class which represents a ResourceContainer which can store Fuel.
 */
public class FuelContainer extends ResourceContainer {

    /**
     * The grade of fuel being stored.
     */
    private FuelGrade grade;

    /**
     * The amount of fuel being stored.
     */
    private int amount;

    /**
     * The maximum capacity of a FuelContainer.
     */
    public static final int MAXIMUM_CAPACITY = 1000;

    /**
     * Constructs a FuelContainer holding a specified amount of Fuel of a specified Grade.
     * @param grade The grade of fuel being stored.
     * @param amount The amount of fuel being stored.
     */
    public FuelContainer(FuelGrade grade, int amount) {
        super(ResourceType.FUEL, amount);
        this.grade = grade;
        this.amount = amount;
    }

    /**
     * Returns the grade of fuel being stored.
     * @return The grade of fuel being stored.
     */
    public FuelGrade getFuelGrade() {
        //Gets the grade of fuel being stored.
        return this.grade;
    }

    /**
     * return true if the ResourceType is FUEL. false if the ResourceType is not FUEL;
     * @param type The type of resource being stored.
     * @return The amount of fuel being stored.
     */
    public boolean canStore(ResourceType type) {
        if (type == ResourceType.FUEL) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns a String representation of this FuelContainer.
     * @return A string of format: "ResourceType: amount - grade"
     */
    public String toString() {
        return String.format("FUEL: %d - %s", this.amount, this.grade);
    }

    /**
     * Returns the short name of the type of fuel stored in this FuelContainer.
     * @return A String containing the type of this resource, based on the FuelType enum.
     */
    public String getShortName() {
        return this.grade.name();
    }

}
