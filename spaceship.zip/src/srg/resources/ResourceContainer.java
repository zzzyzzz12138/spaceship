package srg.resources;

/**
 * A class which represents a ResourceContainer which can store Fuel.
 */
public class ResourceContainer {

    /**
     * The maximum capacity of a FuelContainer.
     */
    public static final int MAXIMUM_CAPACITY = 10;

    /**
     * The type of resource being stored.
     */
    private ResourceType type;

    /**
     * The amount of resource being stored.
     */
    private int amount;

    /**
     * A container filled with a consumable resource
     * @param type The type of resource being stored.
     * @param amount The amount of resource being stored.
     * @throws IllegalArgumentException if the type is FUEL and the class is not FuelContainer
     */
    public ResourceContainer(ResourceType type, int amount) throws IllegalArgumentException {
        if (type == ResourceType.FUEL && this.getClass() != FuelContainer.class) {
            throw new IllegalArgumentException("IllegalArgumentException");
        }
        this.amount = amount;
        this.type = type;
    }

    /**
     * Checks if resources of the specified ResourceType can be stored in this FuelContainer.
     * @param type The type of resource being stored.
     * @return true if the ResourceType is FUEL. false if the ResourceType is not FUEL;
     */
    public boolean canStore(ResourceType type) {
        if (type != ResourceType.FUEL) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Gets the amount of resource stored in this ResourceContainer.
     * @return The amount of resource stored in this ResourceContainer.
     */
    public int getAmount() {
        return this.amount;
    }

    /**
     * Sets the amount of resource stored in this ResourceContainer.
     * @param amount The amount of resource stored in this ResourceContainer.
     */
    public void setAmount(int amount) {
        //Sets the amount of resource stored in this ResourceContainer.
        this.amount = amount;
    }

    /**
     * Returns a String representation of this FuelContainer.
     * @return A string of format: "ResourceType: amount - grade"
     */
    public String toString() {
        return String.format("%s: %d", this.type, this.amount);
    }

    /**
     * Gets the type of resource stored in this ResourceContainer.
     * @return The type of resource stored in this ResourceContainer.
     */
    public ResourceType getType() {
        return this.type;
    }

    /**
     * A String containing the type of this resource, based on the ResourceType enum
     * @return A String containing the type of this resource, based on the ResourceType enum
     */
    public String getShortName() {
        return this.type.name();
    }
}
