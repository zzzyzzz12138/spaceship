package srg.exceptions;

/**
 * Exception thrown when a Ship does not have enough resources to perform an action.
 */
public class NoPathException extends Throwable {

    /**
     * Constructs a NoPathException with no detail message.
     */
    public NoPathException() {

    }

    /**
     * Constructs a NoPathException that contains a helpful detail message explaining why the exception occurred.
     * @param s The detail message.
     */
    public NoPathException(String s) {
        super(s);
    }
}
