package srg.exceptions;

/**
 * Exception thrown when a Ship does not have enough resources to perform an action.
 */
public class InsufficientResourcesException extends Throwable {

    /**
     * Constructs a InsufficientResourcesException with no detail message.
     */
    public InsufficientResourcesException() {
    }

    /**
     * Constructs a InsufficientResourcesException that contains a helpful detail message explaining why the exception occurred.
     * @param message The detail message.
     */
    public InsufficientResourcesException(String message) {
        super(message);
    }
}
