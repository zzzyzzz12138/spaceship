package srg.exceptions;

/**
 * Exception thrown when a Ship does not have enough resources to perform an action.
 */
public class InsufficientCapcaityException extends Throwable {

    /**
     * Constructs a new InsufficientCapcaityException with null as its error message string.
     */
    public InsufficientCapcaityException() {
    }

    /**
     * Constructs a new InsufficientCapcaityException with the specified error message string.
     * @param s The error message string.
     */
    public InsufficientCapcaityException(String s) {
        super(s);
    }
}
